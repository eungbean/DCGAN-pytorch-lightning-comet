# def zeroCenteredGPLoss():
#     return pass
