from .accuracy_CIFAR10 import accuracy
