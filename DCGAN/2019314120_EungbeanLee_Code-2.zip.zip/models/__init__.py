from .generator import Generator
from .discriminator import Discriminator

# from .DCGAN import DCGAN
